package com.example.calculaimc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
